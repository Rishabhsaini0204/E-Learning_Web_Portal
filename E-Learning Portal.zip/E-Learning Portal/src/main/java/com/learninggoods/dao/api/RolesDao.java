package com.learninggoods.dao.api;

import com.learninggoods.dao.entity.Roles;

public interface RolesDao {

	public boolean insert(Roles role);
	
}
